import { Routes } from '@angular/router';
import { Form } from './form/form';


export const routes: Routes = [
     {
        path: '',
        title: 'Inicio - Liqiang Yang',
        component: Form,

    },

    
];
